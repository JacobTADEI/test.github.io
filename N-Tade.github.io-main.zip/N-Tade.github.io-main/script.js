function click_me(text) {
    alert(text);
}